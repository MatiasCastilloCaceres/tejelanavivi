
import React, { useState } from 'react';
import { TextField, Button, Box, Typography, Alert } from '@mui/material';

const ContactForm = () => {
  const [data, setData] = useState({ name: '', email: '', product: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleChange = e => setData({ ...data, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <Box id="contact" sx={{ maxWidth: 600, mx: 'auto', my: 4 }}>
      <Typography variant="h5" gutterBottom>Contáctanos</Typography>
      {sent && <Alert severity="success">Mensaje enviado correctamente</Alert>}
      <form onSubmit={handleSubmit}>
        <TextField fullWidth margin="normal" label="Nombre" name="name" onChange={handleChange} required />
        <TextField fullWidth margin="normal" label="Correo" name="email" type="email" onChange={handleChange} required />
        <TextField fullWidth margin="normal" label="Producto" name="product" onChange={handleChange} />
        <TextField fullWidth margin="normal" multiline rows={4} label="Mensaje" name="message" onChange={handleChange} required />
        <Button type="submit" variant="contained" sx={{ mt: 2 }}>Enviar</Button>
      </form>
    </Box>
  );
};

export default ContactForm;
