
import React from 'react';
import { Container, Typography } from '@mui/material';

const Home = () => (
  <Container sx={{ my: 4 }}>
    <Typography variant="h3" gutterBottom>
      Bienvenidos a Tejelanas Vivi
    </Typography>
    <Typography variant="body1">
      Apoyamos el arte del tejido con productos naturales y talleres en la Laguna de Zapallar.
    </Typography>
  </Container>
);

export default Home;
