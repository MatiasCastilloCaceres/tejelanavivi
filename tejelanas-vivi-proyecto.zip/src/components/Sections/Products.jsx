
import React, { useEffect, useState } from 'react';
import { Container, Grid, Typography } from '@mui/material';
import ProductCard from '../ProductCard';

const Products = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    setProducts([
      { id: 1, title: 'Lana Natural', description: '100% lana natural teñida artesanalmente.', image: 'lana.jpg' },
      { id: 2, title: 'Vellón', description: 'Ideal para fieltro y tejidos suaves.', image: 'vellon.jpg' }
    ]);
  }, []);

  return (
    <Container id="products" sx={{ my: 4 }}>
      <Typography variant="h4" gutterBottom>Productos</Typography>
      <Grid container spacing={4}>
        {products.map(product => (
          <Grid item xs={12} md={6} key={product.id}>
            <ProductCard {...product} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Products;
