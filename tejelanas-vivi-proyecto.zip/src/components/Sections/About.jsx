
import React from 'react';
import { Container, Typography } from '@mui/material';

const About = () => (
  <Container id="about" sx={{ my: 4 }}>
    <Typography variant="h4" gutterBottom>¿Quiénes Somos?</Typography>
    <Typography variant="body1">
      Tejelanas Vivi es un emprendimiento que ofrece lanas naturales, vellón y talleres de crochet.
      Con sede en Laguna de Zapallar, fomentamos la creatividad textil y el aprendizaje comunitario.
    </Typography>
  </Container>
);

export default About;
