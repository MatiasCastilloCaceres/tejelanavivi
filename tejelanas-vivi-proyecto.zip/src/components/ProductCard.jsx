
import React from 'react';
import { Card, CardMedia, CardContent, Typography, CardActions, Button } from '@mui/material';

const ProductCard = ({ image, title, description }) => {
  const handleContact = () => {
    window.location.href = `/contact?product=${encodeURIComponent(title)}`;
  };

  return (
    <Card>
      <CardMedia component="img" height="140" image={\`/images/\${image}\`} alt={title} />
      <CardContent>
        <Typography variant="h6">{title}</Typography>
        <Typography variant="body2" color="text.secondary">{description}</Typography>
      </CardContent>
      <CardActions>
        <Button size="small" onClick={handleContact}>Contáctanos</Button>
      </CardActions>
    </Card>
  );
};

export default ProductCard;
