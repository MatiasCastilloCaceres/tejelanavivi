
import React, { useEffect, useState } from 'react';
import { Accordion, AccordionSummary, AccordionDetails, Typography, Container } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const FAQ = () => {
  const [faqs, setFaqs] = useState([]);

  useEffect(() => {
    setFaqs([
      { question: '¿Realizan envíos?', answer: 'Sí, usamos Starken y Chilexpress.' },
      { question: '¿Dónde están?', answer: 'Laguna de Zapallar.' },
      { question: '¿Cómo inscribirse a talleres?', answer: 'Por Instagram: @teje_lanas.vivi.' }
    ]);
  }, []);

  return (
    <Container id="faq" sx={{ my: 4 }}>
      <Typography variant="h4" gutterBottom>Preguntas Frecuentes</Typography>
      {faqs.map((faq, i) => (
        <Accordion key={i}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>{faq.question}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>{faq.answer}</Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </Container>
  );
};

export default FAQ;
