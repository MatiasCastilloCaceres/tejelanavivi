
import React from 'react';
import Carousel from 'react-material-ui-carousel';
import { Paper, Box } from '@mui/material';

const items = [
  { name: 'Lana Natural', image: '/images/lana.jpg' },
  { name: 'Vellón', image: '/images/vellon.jpg' },
  { name: 'Talleres', image: '/images/taller.jpg' }
];

const ImageCarousel = () => (
  <Box sx={{ maxWidth: 800, mx: 'auto', my: 4 }}>
    <Carousel>
      {items.map((item, i) => (
        <Paper key={i}>
          <img src={item.image} alt={item.name} style={{ width: '100%' }} />
        </Paper>
      ))}
    </Carousel>
  </Box>
);

export default ImageCarousel;
